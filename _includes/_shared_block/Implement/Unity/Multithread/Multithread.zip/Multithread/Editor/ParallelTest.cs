using Extension;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity.Jobs;
using UnityEngine;

public class ParallelTest : MonoBehaviour
{
    const int TEST_COUNT = 10000000;
    const int TEST_THREAD_COUNT = 16;

    [SerializeField] float singleThreadTest;
    [SerializeField] float jobParallelFor;
    [SerializeField] float parallelFor;

    private void Awake()
    {
        Test();
    }

    [ContextMenu("Test")]
    public void Test()
    {
        TestSingleThread();
        TestJobParallelFor();
        TestParallelFor();  
    }

    private void TestSingleThread()
    {
        DateTime start = DateTime.Now;
        for (int i = 0; i < TEST_COUNT; i++)
        {
            TestCalculation();
        }
        singleThreadTest = (float)(DateTime.Now - start).TotalMilliseconds;
    }

    private struct XTestJob : IJobParallelFor
    {
        public void Execute(int index)
        {
            TestCalculation();
        }
    }

    /// <summary>
    /// 잡 시스템을 사용하면 간단하고 안전한 멀티스레드 코드를 작성할 수 있으므로 애플리케이션에서 사용 가능한 모든 CPU 코어를 사용하여 코드를 실행할 수 있습니다.
    /// 이렇게 하면 애플리케이션의 성능을 개선하는 데 도움이 됩니다.
    /// <br>
    /// * https://docs.unity3d.com/kr/current/Manual/JobSystem.html
    /// </br>
    /// </summary>
    private void TestJobParallelFor()
    {
        XTestJob testJob = new XTestJob();

        DateTime start = DateTime.Now;
        var handle = testJob.Schedule(TEST_COUNT, TEST_THREAD_COUNT);
        handle.Complete();
        jobParallelFor = (float)(DateTime.Now - start).TotalMilliseconds;
    }

    /// <summary>
    /// 반복이 병렬로 실행될 수 있는 for(Visual Basic의 경우 For) 루프를 실행합니다.
    /// <br>
    /// * https://learn.microsoft.com/en-us/dotnet/api/system.threading.tasks.parallel.for?view=net-8.0
    /// </br>
    /// </summary>
    private void TestParallelFor()
    {

        DateTime start = DateTime.Now;
        Parallel.For(0, TEST_COUNT, (i) =>
        {
            TestCalculation();
        });
        parallelFor = (float)(DateTime.Now - start).TotalMilliseconds;
    }

    private static void TestCalculation()
    {
        float a = 3;
        for (int i = 0; i < 100; i++)
        {
            a = a * a;
        }
    }
}
