#!/bin/bash

rm -f bin/* src/*.o
